﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ResharperPluginTestProject
{
    public partial class PartialClass
    {
        public DateTime DateTimeProperty { get; set; }
    }
}
