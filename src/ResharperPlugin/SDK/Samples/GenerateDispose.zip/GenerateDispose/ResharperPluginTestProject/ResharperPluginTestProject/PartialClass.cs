﻿namespace ResharperPluginTestProject
{
    public partial class PartialClass
    {
        public string StringProperty { get; set; }
    }
}